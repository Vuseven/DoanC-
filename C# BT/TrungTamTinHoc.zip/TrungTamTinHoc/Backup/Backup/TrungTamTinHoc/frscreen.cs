using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TrungTamTinHoc
{
    public partial class frscreen : Form
    {
        public frscreen()
        {
            InitializeComponent();
        }

        private void frscreen_Load(object sender, EventArgs e)
        {

        }
    }
}