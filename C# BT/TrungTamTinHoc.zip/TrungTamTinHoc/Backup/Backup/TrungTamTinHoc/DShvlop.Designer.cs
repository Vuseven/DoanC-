namespace TrungTamTinHoc
{
    partial class DShvlop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.crvhvl = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // crvhvl
            // 
            this.crvhvl.ActiveViewIndex = -1;
            this.crvhvl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crvhvl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crvhvl.Location = new System.Drawing.Point(0, 0);
            this.crvhvl.Name = "crvhvl";
            this.crvhvl.SelectionFormula = "";
            this.crvhvl.Size = new System.Drawing.Size(292, 266);
            this.crvhvl.TabIndex = 0;
            this.crvhvl.ViewTimeSelectionFormula = "";
            this.crvhvl.Load += new System.EventHandler(this.crvhvl_Load);
            // 
            // DShvlop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 266);
            this.Controls.Add(this.crvhvl);
            this.Name = "DShvlop";
            this.Text = "DShvlop";
            this.ResumeLayout(false);

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer crvhvl;
    }
}