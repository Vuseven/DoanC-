using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.Shared;
using CrystalDecisions.CrystalReports.Engine;
namespace TrungTamTinHoc
{
    public partial class DShvlop : Form
    {
        public DShvlop()
        {
            InitializeComponent();
        }
        public string chuoiloc;
        private void crvhvl_Load(object sender, EventArgs e)
        {
            //frindiemlop diem = new frindiemlop();
            frindshvlop hv = new frindshvlop();
            ReportDocument crpbl = new rpHVtheolop();
            crpbl.RecordSelectionFormula = chuoiloc;
            crvhvl.ReportSource = crpbl;
            crpbl.Refresh();
        }
    }
}